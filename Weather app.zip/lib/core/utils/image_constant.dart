class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // iPhone 14 Pro Max - Four images
  static String
      imgGooglelogopnggoogleiconlogopngtransparentsvgvectorbiesupply141 =
      '$imagePath/img_googlelogopnggoogleiconlogopngtransparentsvgvectorbiesupply14_1.png';

  // iPhone 14 Pro Max - Two images
  static String img171113x114 = '$imagePath/img_171_113x114.png';

  static String img74 = '$imagePath/img_74.png';

  static String img7460x64 = '$imagePath/img_74_60x64.png';

  static String img741 = '$imagePath/img_74_1.png';

  static String imgSearchAmberA200 = '$imagePath/img_search_amber_a200.svg';

  // iPhone 14 Pro Max - Three images
  static String imgEllipse2 = '$imagePath/img_ellipse2.png';

  static String img177 = '$imagePath/img_177.png';

  // Common images
  static String img171 = '$imagePath/img_171.png';

  static String imgHome = '$imagePath/img_home.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgEllipse1 = '$imagePath/img_ellipse1.png';

  static String imgHomeGray400 = '$imagePath/img_home_gray_400.svg';

  static String img173 = '$imagePath/img_173.png';

  static String img174 = '$imagePath/img_174.png';

  static String img175 = '$imagePath/img_175.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
