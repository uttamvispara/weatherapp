final Map<String, String> enUs = {
  // iPhone 14 Pro Max - Four Screen
  "lbl_login": "Login ",
  "lbl_or": "OR",
  "msg_dont_have_a_account": "Dont have a Account?",
  "msg_sign_in_with_google": "Sign in with Google",

  // iPhone 14 Pro Max - Five Screen
  "lbl_first_name": "First Name",
  "lbl_last_name": "Last Name",
  "lbl_register": "Register",
  "msg_already_have_a_account": "Already have a Account?",
  "msg_confirm_password": "Confirm Password",

  // iPhone 14 Pro Max - One - Container Screen
  "lbl_20_august": "20 August ",

  // iPhone 14 Pro Max - Two Screen
  "lbl_21_august": "21 August",
  "lbl_22": "22°",
  "lbl_29": "29°",
  "lbl_forecast": "Forecast",
  "lbl_monday": "Monday",
  "lbl_tuesday": "Tuesday",
  "lbl_wednesday": "Wednesday",

  // iPhone 14 Pro Max - Three Screen
  "lbl_ahmedabad": "Ahmedabad",
  "lbl_favourites": "Favourites",
  "lbl_good_morning": "Good \nMorning",
  "lbl_my_locations": "My Locations",
  "msg_20_august_sunday": "20 August, Sunday",

  // iPhone 14 Pro Max - Six Screen
  "lbl_ahemdabad": "Ahemdabad",
  "msg_chances_of_rain2": "Chances of Rain : 68 %",

  // iPhone 14 Pro Max - Seven Screen
  "lbl_24": "24°", "msg_chances_of_rain3": "Chances of Rain : 81 %",

  // iPhone 14 Pro Max - Eight Screen
  "lbl_30": "30°", "msg_chances_of_rain4": "Chances of Rain : 8 %",

  // Common String
  "lbl_23": "23°",
  "lbl_28": "28°",
  "lbl_29_august": "29 August ",
  "lbl_73": "73%",
  "lbl_9_km_h": "9 km/h",
  "lbl_email": "Email",
  "lbl_login2": "Login",
  "lbl_password": "Password",
  "lbl_rajkot": "Rajkot",
  "lbl_register_now": "Register Now",
  "lbl_surat": "Surat",
  "lbl_vadodara": "Vadodara",
  "msg_chances_of_rain": "Chances of Rain : 19 %",

  // App navigation Screen
  "lbl_app_navigation": "App Navigation",
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",
  "msg_iphone_14_pro_max": "iPhone 14 Pro Max - Four",
  "msg_iphone_14_pro_max2": "iPhone 14 Pro Max - Five",
  "msg_iphone_14_pro_max3": "iPhone 14 Pro Max - One - Container",
  "msg_iphone_14_pro_max4": "iPhone 14 Pro Max - Two",
  "msg_iphone_14_pro_max5": "iPhone 14 Pro Max - Six",
  "msg_iphone_14_pro_max6": "iPhone 14 Pro Max - Seven",
  "msg_iphone_14_pro_max7": "iPhone 14 Pro Max - Eight",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
