import 'bloc/app_navigation_bloc.dart';
import 'models/app_navigation_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<AppNavigationBloc>(
        create: (context) => AppNavigationBloc(
            AppNavigationState(appNavigationModelObj: AppNavigationModel()))
          ..add(AppNavigationInitialEvent()),
        child: AppNavigationScreen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return BlocBuilder<AppNavigationBloc, AppNavigationState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              backgroundColor:
                  theme.colorScheme.onPrimaryContainer.withOpacity(1),
              body: SizedBox(
                  width: 375.h,
                  child: Column(children: [
                    Container(
                        decoration: AppDecoration.fillOnPrimaryContainer1,
                        child: Column(children: [
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 20.h, vertical: 10.v),
                                  child: Text("lbl_app_navigation".tr,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: appTheme.black900,
                                          fontSize: 20.fSize,
                                          fontFamily: 'Roboto',
                                          fontWeight: FontWeight.w400)))),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: EdgeInsets.only(left: 20.h),
                                  child: Text("msg_check_your_app_s".tr,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: appTheme.blueGray40001,
                                          fontSize: 16.fSize,
                                          fontFamily: 'Roboto',
                                          fontWeight: FontWeight.w400)))),
                          SizedBox(height: 5.v),
                          Divider(
                              height: 1.v,
                              thickness: 1.v,
                              color: appTheme.black900)
                        ])),
                    Expanded(
                        child: SingleChildScrollView(
                            child: Container(
                                decoration:
                                    AppDecoration.fillOnPrimaryContainer1,
                                child: Column(children: [
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxFour(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxFive(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max2"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxOneContainer(
                                            context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max3"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxTwo(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max4"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxSix(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max5"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxSeven(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max6"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ]))),
                                  GestureDetector(
                                      onTap: () {
                                        onTapIPhone14ProMaxEight(context);
                                      },
                                      child: Container(
                                          decoration: AppDecoration
                                              .fillOnPrimaryContainer1,
                                          child: Column(children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 20.h,
                                                            vertical: 10.v),
                                                    child: Text(
                                                        "msg_iphone_14_pro_max7"
                                                            .tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: appTheme
                                                                .black900,
                                                            fontSize: 20.fSize,
                                                            fontFamily:
                                                                'Roboto',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)))),
                                            SizedBox(height: 5.v),
                                            Divider(
                                                height: 1.v,
                                                thickness: 1.v,
                                                color: appTheme.blueGray40001)
                                          ])))
                                ]))))
                  ]))));
    });
  }

  /// Navigates to the iphone14ProMaxFourScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxFourScreen.
  onTapIPhone14ProMaxFour(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxFourScreen,
    );
  }

  /// Navigates to the iphone14ProMaxFiveScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxFiveScreen.
  onTapIPhone14ProMaxFive(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxFiveScreen,
    );
  }

  /// Navigates to the iphone14ProMaxOneContainer1Screen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxOneContainer1Screen.
  onTapIPhone14ProMaxOneContainer(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxOneContainer1Screen,
    );
  }

  /// Navigates to the iphone14ProMaxTwoScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxTwoScreen.
  onTapIPhone14ProMaxTwo(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxTwoScreen,
    );
  }

  /// Navigates to the iphone14ProMaxSixScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxSixScreen.
  onTapIPhone14ProMaxSix(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxSixScreen,
    );
  }

  /// Navigates to the iphone14ProMaxSevenScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxSevenScreen.
  onTapIPhone14ProMaxSeven(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxSevenScreen,
    );
  }

  /// Navigates to the iphone14ProMaxEightScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxEightScreen.
  onTapIPhone14ProMaxEight(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxEightScreen,
    );
  }
}
