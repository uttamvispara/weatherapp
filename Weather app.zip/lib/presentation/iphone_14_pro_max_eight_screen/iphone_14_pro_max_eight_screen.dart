import 'bloc/iphone_14_pro_max_eight_bloc.dart';
import 'models/iphone_14_pro_max_eight_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container_page/iphone_14_pro_max_one_container_page.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_three_page/iphone_14_pro_max_three_page.dart';
import 'package:uttam_s_application8/widgets/custom_bottom_bar.dart';

class Iphone14ProMaxEightScreen extends StatelessWidget {
  Iphone14ProMaxEightScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxEightBloc>(
      create: (context) => Iphone14ProMaxEightBloc(Iphone14ProMaxEightState(
        iphone14ProMaxEightModelObj: Iphone14ProMaxEightModel(),
      ))
        ..add(Iphone14ProMaxEightInitialEvent()),
      child: Iphone14ProMaxEightScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone14ProMaxEightBloc, Iphone14ProMaxEightState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
              width: mediaQueryData.size.width,
              height: mediaQueryData.size.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0, -0.22),
                  end: Alignment(1.29, 1.29),
                  colors: [
                    theme.colorScheme.secondaryContainer,
                    appTheme.indigo900,
                  ],
                ),
              ),
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 37.h,
                  vertical: 49.v,
                ),
                child: Column(
                  children: [
                    SizedBox(height: 4.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: SizedBox(
                        height: 491.v,
                        width: 326.h,
                        child: Stack(
                          alignment: Alignment.centerLeft,
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                height: 300.v,
                                width: 326.h,
                                margin: EdgeInsets.only(top: 79.v),
                                child: Stack(
                                  alignment: Alignment.topLeft,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "lbl_30".tr,
                                        style: CustomTextStyles.poppinsBlue5001,
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Container(
                                        margin: EdgeInsets.only(
                                          left: 17.h,
                                          top: 10.v,
                                        ),
                                        decoration: AppDecoration.outlineBlack,
                                        child: Text(
                                          "msg_chances_of_rain4".tr,
                                          style: theme.textTheme.headlineSmall,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: EdgeInsets.only(left: 23.h),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(left: 46.h),
                                      decoration: AppDecoration.outlineBlack,
                                      child: Text(
                                        "lbl_surat".tr,
                                        style: theme.textTheme.displayLarge,
                                      ),
                                    ),
                                    SizedBox(height: 146.v),
                                    CustomImageView(
                                      imagePath: ImageConstant.img175,
                                      height: 255.v,
                                      width: 260.h,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 49.v),
                    Text(
                      "lbl_29_august".tr,
                      style: theme.textTheme.displaySmall,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 4.h,
                        top: 84.v,
                        right: 5.h,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "lbl_9_km_h".tr,
                            style: theme.textTheme.headlineSmall,
                          ),
                          Text(
                            "lbl_73".tr,
                            style: theme.textTheme.headlineSmall,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Search:
        return AppRoutes.iphone14ProMaxOneContainerPage;
      case BottomBarEnum.Ellipse1:
        return AppRoutes.iphone14ProMaxThreePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.iphone14ProMaxOneContainerPage:
        return Iphone14ProMaxOneContainerPage.builder(context);
      case AppRoutes.iphone14ProMaxThreePage:
        return Iphone14ProMaxThreePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
