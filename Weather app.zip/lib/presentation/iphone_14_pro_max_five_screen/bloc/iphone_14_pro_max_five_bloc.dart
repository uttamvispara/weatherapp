import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_five_screen/models/iphone_14_pro_max_five_model.dart';
part 'iphone_14_pro_max_five_event.dart';
part 'iphone_14_pro_max_five_state.dart';

/// A bloc that manages the state of a Iphone14ProMaxFive according to the event that is dispatched to it.
class Iphone14ProMaxFiveBloc
    extends Bloc<Iphone14ProMaxFiveEvent, Iphone14ProMaxFiveState> {
  Iphone14ProMaxFiveBloc(Iphone14ProMaxFiveState initialState)
      : super(initialState) {
    on<Iphone14ProMaxFiveInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone14ProMaxFiveInitialEvent event,
    Emitter<Iphone14ProMaxFiveState> emit,
  ) async {
    emit(state.copyWith(
        firstNameController: TextEditingController(),
        lastNameController: TextEditingController(),
        emailController: TextEditingController(),
        passwordController: TextEditingController(),
        confirmpasswordController: TextEditingController()));
  }
}
