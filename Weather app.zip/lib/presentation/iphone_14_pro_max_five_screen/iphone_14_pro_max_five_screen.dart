import 'bloc/iphone_14_pro_max_five_bloc.dart';
import 'models/iphone_14_pro_max_five_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/core/utils/validation_functions.dart';
import 'package:uttam_s_application8/widgets/custom_elevated_button.dart';
import 'package:uttam_s_application8/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class Iphone14ProMaxFiveScreen extends StatelessWidget {
  Iphone14ProMaxFiveScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxFiveBloc>(
        create: (context) => Iphone14ProMaxFiveBloc(Iphone14ProMaxFiveState(
            iphone14ProMaxFiveModelObj: Iphone14ProMaxFiveModel()))
          ..add(Iphone14ProMaxFiveInitialEvent()),
        child: Iphone14ProMaxFiveScreen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: mediaQueryData.size.width,
                height: mediaQueryData.size.height,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0, -0.22),
                        end: Alignment(1.29, 1.29),
                        colors: [
                      theme.colorScheme.secondaryContainer,
                      appTheme.indigo900
                    ])),
                child: Form(
                    key: _formKey,
                    child: Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.symmetric(
                            horizontal: 21.h, vertical: 54.v),
                        child: Column(children: [
                          Container(
                              decoration: AppDecoration.outlineBlack,
                              child: Text("lbl_register".tr,
                                  style: CustomTextStyles.displayMediumTeal50)),
                          Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 35.h, vertical: 40.v),
                              decoration: AppDecoration.fillOnPrimaryContainer
                                  .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder43),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    BlocSelector<
                                            Iphone14ProMaxFiveBloc,
                                            Iphone14ProMaxFiveState,
                                            TextEditingController?>(
                                        selector: (state) =>
                                            state.firstNameController,
                                        builder:
                                            (context, firstNameController) {
                                          return CustomTextFormField(
                                              controller: firstNameController,
                                              hintText: "lbl_first_name".tr,
                                              validator: (value) {
                                                if (!isText(value)) {
                                                  return "Please enter valid text";
                                                }
                                                return null;
                                              });
                                        }),
                                    SizedBox(height: 23.v),
                                    BlocSelector<
                                            Iphone14ProMaxFiveBloc,
                                            Iphone14ProMaxFiveState,
                                            TextEditingController?>(
                                        selector: (state) =>
                                            state.lastNameController,
                                        builder: (context, lastNameController) {
                                          return CustomTextFormField(
                                              controller: lastNameController,
                                              hintText: "lbl_last_name".tr,
                                              validator: (value) {
                                                if (!isText(value)) {
                                                  return "Please enter valid text";
                                                }
                                                return null;
                                              });
                                        }),
                                    SizedBox(height: 23.v),
                                    BlocSelector<
                                            Iphone14ProMaxFiveBloc,
                                            Iphone14ProMaxFiveState,
                                            TextEditingController?>(
                                        selector: (state) =>
                                            state.emailController,
                                        builder: (context, emailController) {
                                          return CustomTextFormField(
                                              controller: emailController,
                                              hintText: "lbl_email".tr,
                                              textInputType:
                                                  TextInputType.emailAddress,
                                              validator: (value) {
                                                if (value == null ||
                                                    (!isValidEmail(value,
                                                        isRequired: true))) {
                                                  return "Please enter valid email";
                                                }
                                                return null;
                                              });
                                        }),
                                    SizedBox(height: 23.v),
                                    BlocSelector<
                                            Iphone14ProMaxFiveBloc,
                                            Iphone14ProMaxFiveState,
                                            TextEditingController?>(
                                        selector: (state) =>
                                            state.passwordController,
                                        builder: (context, passwordController) {
                                          return CustomTextFormField(
                                              controller: passwordController,
                                              hintText: "lbl_password".tr,
                                              textInputType:
                                                  TextInputType.visiblePassword,
                                              validator: (value) {
                                                if (value == null ||
                                                    (!isValidPassword(value,
                                                        isRequired: true))) {
                                                  return "Please enter valid password";
                                                }
                                                return null;
                                              },
                                              obscureText: true);
                                        }),
                                    SizedBox(height: 23.v),
                                    BlocSelector<
                                            Iphone14ProMaxFiveBloc,
                                            Iphone14ProMaxFiveState,
                                            TextEditingController?>(
                                        selector: (state) =>
                                            state.confirmpasswordController,
                                        builder: (context,
                                            confirmpasswordController) {
                                          return CustomTextFormField(
                                              controller:
                                                  confirmpasswordController,
                                              hintText:
                                                  "msg_confirm_password".tr,
                                              textInputAction:
                                                  TextInputAction.done,
                                              textInputType:
                                                  TextInputType.visiblePassword,
                                              validator: (value) {
                                                if (value == null ||
                                                    (!isValidPassword(value,
                                                        isRequired: true))) {
                                                  return "Please enter valid password";
                                                }
                                                return null;
                                              },
                                              obscureText: true);
                                        }),
                                    SizedBox(height: 23.v),
                                    CustomElevatedButton(
                                        text: "lbl_register_now".tr,
                                        buttonStyle: CustomButtonStyles
                                            .fillPrimaryContainer)
                                  ])),
                          SizedBox(height: 33.v),
                          Text("msg_already_have_a_account".tr,
                              style: CustomTextStyles
                                  .headlineSmallOnPrimaryContainer),
                          CustomElevatedButton(
                              text: "lbl_login2".tr,
                              margin:
                                  EdgeInsets.fromLTRB(35.h, 10.v, 35.h, 5.v),
                              buttonTextStyle: CustomTextStyles
                                  .headlineSmallPrimaryContainer,
                              onTap: () {
                                onTapLogin(context);
                              })
                        ]))))));
  }

  /// Navigates to the iphone14ProMaxFourScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxFourScreen.
  onTapLogin(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxFourScreen,
    );
  }
}
