import 'bloc/iphone_14_pro_max_four_bloc.dart';
import 'models/iphone_14_pro_max_four_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/core/utils/validation_functions.dart';
import 'package:uttam_s_application8/widgets/custom_elevated_button.dart';
import 'package:uttam_s_application8/widgets/custom_text_form_field.dart';
import 'package:uttam_s_application8/domain/googleauth/google_auth_helper.dart';

// ignore_for_file: must_be_immutable
class Iphone14ProMaxFourScreen extends StatelessWidget {
  Iphone14ProMaxFourScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxFourBloc>(
        create: (context) => Iphone14ProMaxFourBloc(Iphone14ProMaxFourState(
            iphone14ProMaxFourModelObj: Iphone14ProMaxFourModel()))
          ..add(Iphone14ProMaxFourInitialEvent()),
        child: Iphone14ProMaxFourScreen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            body: Container(
                width: mediaQueryData.size.width,
                height: mediaQueryData.size.height,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0, -0.22),
                        end: Alignment(1.29, 1.29),
                        colors: [
                      theme.colorScheme.secondaryContainer,
                      appTheme.indigo900
                    ])),
                child: Form(
                    key: _formKey,
                    child: Container(
                        width: double.maxFinite,
                        padding: EdgeInsets.symmetric(horizontal: 21.h),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                  decoration: AppDecoration.outlineBlack,
                                  child: Text("lbl_login".tr,
                                      style: CustomTextStyles
                                          .displayMediumTeal50)),
                              Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 35.h, vertical: 36.v),
                                  decoration: AppDecoration
                                      .fillOnPrimaryContainer
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder43),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(height: 4.v),
                                        BlocSelector<
                                                Iphone14ProMaxFourBloc,
                                                Iphone14ProMaxFourState,
                                                TextEditingController?>(
                                            selector: (state) =>
                                                state.emailController,
                                            builder:
                                                (context, emailController) {
                                              return CustomTextFormField(
                                                  controller: emailController,
                                                  hintText: "lbl_email".tr,
                                                  textInputType: TextInputType
                                                      .emailAddress,
                                                  validator: (value) {
                                                    if (value == null ||
                                                        (!isValidEmail(value,
                                                            isRequired:
                                                                true))) {
                                                      return "Please enter valid email";
                                                    }
                                                    return null;
                                                  });
                                            }),
                                        SizedBox(height: 23.v),
                                        BlocSelector<
                                                Iphone14ProMaxFourBloc,
                                                Iphone14ProMaxFourState,
                                                TextEditingController?>(
                                            selector: (state) =>
                                                state.passwordController,
                                            builder:
                                                (context, passwordController) {
                                              return CustomTextFormField(
                                                  controller:
                                                      passwordController,
                                                  hintText: "lbl_password".tr,
                                                  textInputAction:
                                                      TextInputAction.done,
                                                  textInputType: TextInputType
                                                      .visiblePassword,
                                                  validator: (value) {
                                                    if (value == null ||
                                                        (!isValidPassword(value,
                                                            isRequired:
                                                                true))) {
                                                      return "Please enter valid password";
                                                    }
                                                    return null;
                                                  },
                                                  obscureText: true);
                                            }),
                                        SizedBox(height: 24.v),
                                        CustomElevatedButton(
                                            text: "lbl_login2".tr,
                                            buttonStyle: CustomButtonStyles
                                                .fillPrimaryContainer,
                                            onTap: () {
                                              onTapLogin(context);
                                            }),
                                        SizedBox(height: 2.v),
                                        Text("lbl_or".tr,
                                            style: CustomTextStyles
                                                .headlineSmallOnPrimaryContainer),
                                        SizedBox(height: 3.v),
                                        CustomElevatedButton(
                                            text: "msg_sign_in_with_google".tr,
                                            leftIcon: Container(
                                                margin: EdgeInsets.only(
                                                    right: 12.h),
                                                child: CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgGooglelogopnggoogleiconlogopngtransparentsvgvectorbiesupply141,
                                                    height: 30.adaptSize,
                                                    width: 30.adaptSize)),
                                            buttonTextStyle: CustomTextStyles
                                                .headlineSmallBlack900_1,
                                            onTap: () {
                                              onTapSigninwith(context);
                                            })
                                      ])),
                              Padding(
                                  padding: EdgeInsets.only(top: 32.v),
                                  child: Divider(
                                      color: theme.colorScheme.errorContainer,
                                      indent: 19.h)),
                              SizedBox(height: 10.v),
                              Text("msg_dont_have_a_account".tr,
                                  style: CustomTextStyles
                                      .headlineSmallOnPrimaryContainer),
                              CustomElevatedButton(
                                  text: "lbl_register_now".tr,
                                  margin: EdgeInsets.fromLTRB(
                                      35.h, 13.v, 35.h, 5.v),
                                  buttonTextStyle: CustomTextStyles
                                      .headlineSmallPrimaryContainer,
                                  onTap: () {
                                    onTapRegisternow(context);
                                  })
                            ]))))));
  }

  /// Navigates to the iphone14ProMaxOneContainer1Screen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxOneContainer1Screen.
  onTapLogin(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxOneContainer1Screen,
    );
  }

  /// Performs a Google sign-in and returns a [GoogleUser] object.
  ///
  /// If the sign-in is successful, the [onSuccess] callback will be called with
  /// a TODO comment needed to be modified by you.
  /// If the sign-in fails, the [onError] callback will be called with the error message.
  ///
  /// Throws an exception if the Google sign-in process fails.
  onTapSigninwith(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        //TODO Actions to be performed after signin
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('user data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }

  /// Navigates to the iphone14ProMaxFiveScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxFiveScreen.
  onTapRegisternow(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxFiveScreen,
    );
  }
}
