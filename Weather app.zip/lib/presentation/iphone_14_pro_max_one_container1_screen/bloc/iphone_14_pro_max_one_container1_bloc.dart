import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container1_screen/models/iphone_14_pro_max_one_container1_model.dart';
part 'iphone_14_pro_max_one_container1_event.dart';
part 'iphone_14_pro_max_one_container1_state.dart';

/// A bloc that manages the state of a Iphone14ProMaxOneContainer1 according to the event that is dispatched to it.
class Iphone14ProMaxOneContainer1Bloc extends Bloc<
    Iphone14ProMaxOneContainer1Event, Iphone14ProMaxOneContainer1State> {
  Iphone14ProMaxOneContainer1Bloc(Iphone14ProMaxOneContainer1State initialState)
      : super(initialState) {
    on<Iphone14ProMaxOneContainer1InitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone14ProMaxOneContainer1InitialEvent event,
    Emitter<Iphone14ProMaxOneContainer1State> emit,
  ) async {}
}
