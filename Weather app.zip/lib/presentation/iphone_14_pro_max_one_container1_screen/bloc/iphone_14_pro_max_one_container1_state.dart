// ignore_for_file: must_be_immutable

part of 'iphone_14_pro_max_one_container1_bloc.dart';

/// Represents the state of Iphone14ProMaxOneContainer1 in the application.
class Iphone14ProMaxOneContainer1State extends Equatable {
  Iphone14ProMaxOneContainer1State({this.iphone14ProMaxOneContainer1ModelObj});

  Iphone14ProMaxOneContainer1Model? iphone14ProMaxOneContainer1ModelObj;

  @override
  List<Object?> get props => [
        iphone14ProMaxOneContainer1ModelObj,
      ];
  Iphone14ProMaxOneContainer1State copyWith(
      {Iphone14ProMaxOneContainer1Model? iphone14ProMaxOneContainer1ModelObj}) {
    return Iphone14ProMaxOneContainer1State(
      iphone14ProMaxOneContainer1ModelObj:
          iphone14ProMaxOneContainer1ModelObj ??
              this.iphone14ProMaxOneContainer1ModelObj,
    );
  }
}
