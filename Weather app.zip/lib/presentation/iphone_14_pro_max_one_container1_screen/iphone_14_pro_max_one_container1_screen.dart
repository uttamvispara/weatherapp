import 'bloc/iphone_14_pro_max_one_container1_bloc.dart';
import 'models/iphone_14_pro_max_one_container1_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container_page/iphone_14_pro_max_one_container_page.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_three_page/iphone_14_pro_max_three_page.dart';
import 'package:uttam_s_application8/widgets/custom_bottom_bar.dart';

// ignore_for_file: must_be_immutable
class Iphone14ProMaxOneContainer1Screen extends StatelessWidget {
  Iphone14ProMaxOneContainer1Screen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxOneContainer1Bloc>(
        create: (context) => Iphone14ProMaxOneContainer1Bloc(
            Iphone14ProMaxOneContainer1State(
                iphone14ProMaxOneContainer1ModelObj:
                    Iphone14ProMaxOneContainer1Model()))
          ..add(Iphone14ProMaxOneContainer1InitialEvent()),
        child: Iphone14ProMaxOneContainer1Screen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return BlocBuilder<Iphone14ProMaxOneContainer1Bloc,
        Iphone14ProMaxOneContainer1State>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              extendBody: true,
              extendBodyBehindAppBar: true,
              body: Container(
                  width: mediaQueryData.size.width,
                  height: mediaQueryData.size.height,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment(0, -0.22),
                          end: Alignment(1.29, 1.29),
                          colors: [
                        theme.colorScheme.surfaceVariant,
                        appTheme.indigo900
                      ])),
                  child: Navigator(
                      key: navigatorKey,
                      initialRoute: AppRoutes.iphone14ProMaxOneContainerPage,
                      onGenerateRoute: (routeSetting) => PageRouteBuilder(
                          pageBuilder: (ctx, ani, ani1) =>
                              getCurrentPage(context, routeSetting.name!),
                          transitionDuration: Duration(seconds: 0)))),
              bottomNavigationBar:
                  CustomBottomBar(onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              })));
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Search:
        return AppRoutes.iphone14ProMaxOneContainerPage;
      case BottomBarEnum.Ellipse1:
        return AppRoutes.iphone14ProMaxThreePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.iphone14ProMaxOneContainerPage:
        return Iphone14ProMaxOneContainerPage.builder(context);
      case AppRoutes.iphone14ProMaxThreePage:
        return Iphone14ProMaxThreePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
