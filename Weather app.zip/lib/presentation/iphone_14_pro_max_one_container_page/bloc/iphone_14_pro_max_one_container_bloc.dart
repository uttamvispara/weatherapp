import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container_page/models/iphone_14_pro_max_one_container_model.dart';
part 'iphone_14_pro_max_one_container_event.dart';
part 'iphone_14_pro_max_one_container_state.dart';

/// A bloc that manages the state of a Iphone14ProMaxOneContainer according to the event that is dispatched to it.
class Iphone14ProMaxOneContainerBloc extends Bloc<
    Iphone14ProMaxOneContainerEvent, Iphone14ProMaxOneContainerState> {
  Iphone14ProMaxOneContainerBloc(Iphone14ProMaxOneContainerState initialState)
      : super(initialState) {
    on<Iphone14ProMaxOneContainerInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone14ProMaxOneContainerInitialEvent event,
    Emitter<Iphone14ProMaxOneContainerState> emit,
  ) async {}
}
