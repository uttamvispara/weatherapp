// ignore_for_file: must_be_immutable

part of 'iphone_14_pro_max_one_container_bloc.dart';

/// Represents the state of Iphone14ProMaxOneContainer in the application.
class Iphone14ProMaxOneContainerState extends Equatable {
  Iphone14ProMaxOneContainerState({this.iphone14ProMaxOneContainerModelObj});

  Iphone14ProMaxOneContainerModel? iphone14ProMaxOneContainerModelObj;

  @override
  List<Object?> get props => [
        iphone14ProMaxOneContainerModelObj,
      ];
  Iphone14ProMaxOneContainerState copyWith(
      {Iphone14ProMaxOneContainerModel? iphone14ProMaxOneContainerModelObj}) {
    return Iphone14ProMaxOneContainerState(
      iphone14ProMaxOneContainerModelObj: iphone14ProMaxOneContainerModelObj ??
          this.iphone14ProMaxOneContainerModelObj,
    );
  }
}
