import 'bloc/iphone_14_pro_max_one_container_bloc.dart';
import 'models/iphone_14_pro_max_one_container_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';

// ignore_for_file: must_be_immutable
class Iphone14ProMaxOneContainerPage extends StatelessWidget {
  const Iphone14ProMaxOneContainerPage({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxOneContainerBloc>(
      create: (context) =>
          Iphone14ProMaxOneContainerBloc(Iphone14ProMaxOneContainerState(
        iphone14ProMaxOneContainerModelObj: Iphone14ProMaxOneContainerModel(),
      ))
            ..add(Iphone14ProMaxOneContainerInitialEvent()),
      child: Iphone14ProMaxOneContainerPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone14ProMaxOneContainerBloc,
        Iphone14ProMaxOneContainerState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            backgroundColor: Colors.transparent,
            body: Container(
              width: mediaQueryData.size.width,
              height: mediaQueryData.size.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0, -0.22),
                  end: Alignment(1.29, 1.29),
                  colors: [
                    theme.colorScheme.surfaceVariant,
                    appTheme.indigo900,
                  ],
                ),
              ),
              child: Container(
                width: double.maxFinite,
                decoration: AppDecoration.gradientSurfaceVariantToIndigo,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 41.h,
                    vertical: 49.v,
                  ),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          height: 510.v,
                          width: 315.h,
                          margin: EdgeInsets.only(
                            top: 4.v,
                            right: 7.h,
                          ),
                          child: Stack(
                            alignment: Alignment.centerLeft,
                            children: [
                              Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                  padding: EdgeInsets.only(top: 79.v),
                                  child: Text(
                                    "lbl_23".tr,
                                    style: CustomTextStyles.poppinsBlue5001,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 24.h),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        decoration: AppDecoration.outlineBlack,
                                        child: Text(
                                          "lbl_rajkot".tr,
                                          style:
                                              CustomTextStyles.displayLarge64,
                                        ),
                                      ),
                                      SizedBox(height: 169.v),
                                      CustomImageView(
                                        imagePath: ImageConstant.img171,
                                        height: 245.v,
                                        width: 248.h,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  margin: EdgeInsets.only(
                                    left: 17.h,
                                    top: 90.v,
                                  ),
                                  decoration: AppDecoration.outlineBlack,
                                  child: Text(
                                    "msg_chances_of_rain".tr,
                                    style: theme.textTheme.headlineSmall,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 31.v),
                      Text(
                        "lbl_20_august".tr,
                        style: theme.textTheme.displaySmall,
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: 84.v,
                          right: 1.h,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "lbl_9_km_h".tr,
                              style: theme.textTheme.headlineSmall,
                            ),
                            Text(
                              "lbl_73".tr,
                              style: theme.textTheme.headlineSmall,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
