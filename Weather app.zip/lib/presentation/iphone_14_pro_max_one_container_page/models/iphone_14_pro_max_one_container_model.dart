// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_pro_max_one_container_page],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone14ProMaxOneContainerModel extends Equatable {
  Iphone14ProMaxOneContainerModel() {}

  Iphone14ProMaxOneContainerModel copyWith() {
    return Iphone14ProMaxOneContainerModel();
  }

  @override
  List<Object?> get props => [];
}
