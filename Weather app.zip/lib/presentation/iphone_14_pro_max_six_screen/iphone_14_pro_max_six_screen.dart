import 'bloc/iphone_14_pro_max_six_bloc.dart';
import 'models/iphone_14_pro_max_six_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container_page/iphone_14_pro_max_one_container_page.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_three_page/iphone_14_pro_max_three_page.dart';
import 'package:uttam_s_application8/widgets/custom_bottom_bar.dart';

class Iphone14ProMaxSixScreen extends StatelessWidget {
  Iphone14ProMaxSixScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxSixBloc>(
      create: (context) => Iphone14ProMaxSixBloc(Iphone14ProMaxSixState(
        iphone14ProMaxSixModelObj: Iphone14ProMaxSixModel(),
      ))
        ..add(Iphone14ProMaxSixInitialEvent()),
      child: Iphone14ProMaxSixScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone14ProMaxSixBloc, Iphone14ProMaxSixState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
              width: mediaQueryData.size.width,
              height: mediaQueryData.size.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0, -0.22),
                  end: Alignment(1.29, 1.29),
                  colors: [
                    theme.colorScheme.secondaryContainer,
                    appTheme.indigo900,
                  ],
                ),
              ),
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 24.h,
                  vertical: 49.v,
                ),
                child: Column(
                  children: [
                    SizedBox(height: 4.v),
                    SizedBox(
                      height: 523.v,
                      width: 381.h,
                      child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Align(
                            alignment: Alignment.topRight,
                            child: Container(
                              height: 300.v,
                              width: 324.h,
                              margin: EdgeInsets.only(
                                top: 81.v,
                                right: 15.h,
                              ),
                              child: Stack(
                                alignment: Alignment.topLeft,
                                children: [
                                  Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      "lbl_28".tr,
                                      style: CustomTextStyles.poppinsBlue5001,
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Container(
                                      margin: EdgeInsets.only(
                                        left: 17.h,
                                        top: 8.v,
                                      ),
                                      decoration: AppDecoration.outlineBlack,
                                      child: Text(
                                        "msg_chances_of_rain2".tr,
                                        style: theme.textTheme.headlineSmall,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              decoration: AppDecoration.outlineBlack,
                              child: Text(
                                "lbl_ahemdabad".tr,
                                style: theme.textTheme.displayLarge,
                              ),
                            ),
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.img173,
                            height: 295.v,
                            width: 300.h,
                            alignment: Alignment.bottomCenter,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 18.v),
                    Text(
                      "lbl_29_august".tr,
                      style: theme.textTheme.displaySmall,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 17.h,
                        top: 84.v,
                        right: 17.h,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "lbl_9_km_h".tr,
                            style: theme.textTheme.headlineSmall,
                          ),
                          Text(
                            "lbl_73".tr,
                            style: theme.textTheme.headlineSmall,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Search:
        return AppRoutes.iphone14ProMaxOneContainerPage;
      case BottomBarEnum.Ellipse1:
        return AppRoutes.iphone14ProMaxThreePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.iphone14ProMaxOneContainerPage:
        return Iphone14ProMaxOneContainerPage.builder(context);
      case AppRoutes.iphone14ProMaxThreePage:
        return Iphone14ProMaxThreePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
