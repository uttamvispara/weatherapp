import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_three_page/models/iphone_14_pro_max_three_model.dart';
part 'iphone_14_pro_max_three_event.dart';
part 'iphone_14_pro_max_three_state.dart';

/// A bloc that manages the state of a Iphone14ProMaxThree according to the event that is dispatched to it.
class Iphone14ProMaxThreeBloc
    extends Bloc<Iphone14ProMaxThreeEvent, Iphone14ProMaxThreeState> {
  Iphone14ProMaxThreeBloc(Iphone14ProMaxThreeState initialState)
      : super(initialState) {
    on<Iphone14ProMaxThreeInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone14ProMaxThreeInitialEvent event,
    Emitter<Iphone14ProMaxThreeState> emit,
  ) async {}
}
