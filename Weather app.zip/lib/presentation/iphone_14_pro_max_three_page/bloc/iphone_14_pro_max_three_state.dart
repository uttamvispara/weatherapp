// ignore_for_file: must_be_immutable

part of 'iphone_14_pro_max_three_bloc.dart';

/// Represents the state of Iphone14ProMaxThree in the application.
class Iphone14ProMaxThreeState extends Equatable {
  Iphone14ProMaxThreeState({this.iphone14ProMaxThreeModelObj});

  Iphone14ProMaxThreeModel? iphone14ProMaxThreeModelObj;

  @override
  List<Object?> get props => [
        iphone14ProMaxThreeModelObj,
      ];
  Iphone14ProMaxThreeState copyWith(
      {Iphone14ProMaxThreeModel? iphone14ProMaxThreeModelObj}) {
    return Iphone14ProMaxThreeState(
      iphone14ProMaxThreeModelObj:
          iphone14ProMaxThreeModelObj ?? this.iphone14ProMaxThreeModelObj,
    );
  }
}
