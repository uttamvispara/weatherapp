import 'bloc/iphone_14_pro_max_three_bloc.dart';
import 'models/iphone_14_pro_max_three_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/widgets/app_bar/appbar_circleimage.dart';
import 'package:uttam_s_application8/widgets/app_bar/appbar_subtitle.dart';
import 'package:uttam_s_application8/widgets/app_bar/custom_app_bar.dart';

class Iphone14ProMaxThreePage extends StatelessWidget {
  const Iphone14ProMaxThreePage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxThreeBloc>(
        create: (context) => Iphone14ProMaxThreeBloc(Iphone14ProMaxThreeState(
            iphone14ProMaxThreeModelObj: Iphone14ProMaxThreeModel()))
          ..add(Iphone14ProMaxThreeInitialEvent()),
        child: Iphone14ProMaxThreePage());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return BlocBuilder<Iphone14ProMaxThreeBloc, Iphone14ProMaxThreeState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              backgroundColor: theme.colorScheme.onInverseSurface,
              appBar: CustomAppBar(
                  title: AppbarSubtitle(
                      text: "lbl_good_morning".tr,
                      margin: EdgeInsets.only(left: 38.h)),
                  actions: [
                    AppbarCircleimage(
                        imagePath: ImageConstant.imgEllipse2,
                        margin: EdgeInsets.fromLTRB(25.h, 4.v, 25.h, 16.v))
                  ]),
              body: Container(
                  width: 432.h,
                  padding: EdgeInsets.symmetric(horizontal: 38.h),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                            padding: EdgeInsets.only(left: 3.h),
                            child: Text("msg_20_august_sunday".tr,
                                style: CustomTextStyles.titleLargeBluegray400)),
                        Padding(
                            padding: EdgeInsets.only(left: 6.h, top: 18.v),
                            child: Text("lbl_my_locations".tr,
                                style: CustomTextStyles.headlineSmallBlack900)),
                        Card(
                            clipBehavior: Clip.antiAlias,
                            elevation: 0,
                            margin: EdgeInsets.only(left: 4.h, top: 14.v),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadiusStyle.roundedBorder27),
                            child: Container(
                                height: 302.v,
                                width: 348.h,
                                padding: EdgeInsets.symmetric(
                                    horizontal: 31.h, vertical: 20.v),
                                decoration: AppDecoration.gradientIndigoToIndigo
                                    .copyWith(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder27),
                                child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Align(
                                          alignment: Alignment.center,
                                          child: SizedBox(
                                              height: 259.v,
                                              child: VerticalDivider(
                                                  width: 1.h, thickness: 1.v))),
                                      Align(
                                          alignment: Alignment.center,
                                          child: SizedBox(
                                              width: 259.h, child: Divider())),
                                      Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  left: 33.h, top: 6.v),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                        decoration:
                                                            AppDecoration
                                                                .outlineBlack,
                                                        child: Text(
                                                            "lbl_rajkot".tr,
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge)),
                                                    SizedBox(height: 10.v),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .img171,
                                                        height: 59.v,
                                                        width: 60.h,
                                                        alignment: Alignment
                                                            .centerRight,
                                                        onTap: () {
                                                          onTapImgImage(
                                                              context);
                                                        })
                                                  ]))),
                                      Align(
                                          alignment: Alignment.topRight,
                                          child: Padding(
                                              padding:
                                                  EdgeInsets.only(top: 6.v),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Container(
                                                        decoration:
                                                            AppDecoration
                                                                .outlineBlack,
                                                        child: Text(
                                                            "lbl_ahmedabad".tr,
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge)),
                                                    SizedBox(height: 6.v),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .img173,
                                                        height: 65.v,
                                                        width: 66.h,
                                                        onTap: () {
                                                          onTapImgImageone(
                                                              context);
                                                        })
                                                  ]))),
                                      Align(
                                          alignment: Alignment.bottomLeft,
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  left: 9.h, bottom: 31.v),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  children: [
                                                    Container(
                                                        decoration:
                                                            AppDecoration
                                                                .outlineBlack,
                                                        child: Text(
                                                            "lbl_vadodara".tr,
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge)),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .img174,
                                                        height: 59.v,
                                                        width: 60.h,
                                                        margin: EdgeInsets.only(
                                                            top: 6.v,
                                                            right: 14.h),
                                                        onTap: () {
                                                          onTapImgImagetwo(
                                                              context);
                                                        })
                                                  ]))),
                                      Align(
                                          alignment: Alignment.bottomRight,
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: 29.h, bottom: 31.v),
                                              child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                        decoration:
                                                            AppDecoration
                                                                .outlineBlack,
                                                        child: Text(
                                                            "lbl_surat".tr,
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge)),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .img175,
                                                        height: 59.v,
                                                        width: 60.h,
                                                        margin: EdgeInsets.only(
                                                            left: 3.h,
                                                            top: 6.v),
                                                        onTap: () {
                                                          onTapImgImagethree(
                                                              context);
                                                        })
                                                  ])))
                                    ]))),
                        Padding(
                            padding: EdgeInsets.only(left: 6.h, top: 24.v),
                            child: Text("lbl_favourites".tr,
                                style: CustomTextStyles.headlineSmallBlack900)),
                        Container(
                            margin: EdgeInsets.only(
                                top: 11.v, right: 8.h, bottom: 5.v),
                            padding: EdgeInsets.symmetric(
                                horizontal: 29.h, vertical: 21.v),
                            decoration: AppDecoration.gradientIndigoToIndigo
                                .copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder27),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                      padding: EdgeInsets.only(
                                          left: 39.h, bottom: 6.v),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                                decoration:
                                                    AppDecoration.outlineBlack,
                                                child: Text("lbl_rajkot".tr,
                                                    style: theme
                                                        .textTheme.titleLarge)),
                                            SizedBox(height: 10.v),
                                            CustomImageView(
                                                imagePath: ImageConstant.img171,
                                                height: 59.v,
                                                width: 60.h,
                                                alignment:
                                                    Alignment.centerRight,
                                                onTap: () {
                                                  onTapImgImagefour(context);
                                                })
                                          ])),
                                  Padding(
                                      padding: EdgeInsets.only(left: 46.h),
                                      child: SizedBox(
                                          height: 105.v,
                                          child: VerticalDivider(
                                              width: 1.h,
                                              thickness: 1.v,
                                              indent: 4.h))),
                                  Container(
                                      height: 101.v,
                                      width: 127.h,
                                      margin: EdgeInsets.only(left: 13.h),
                                      child: Stack(
                                          alignment: Alignment.bottomRight,
                                          children: [
                                            Align(
                                                alignment: Alignment.topCenter,
                                                child: Container(
                                                    decoration: AppDecoration
                                                        .outlineBlack,
                                                    child: Text(
                                                        "lbl_ahmedabad".tr,
                                                        style: theme.textTheme
                                                            .titleLarge))),
                                            CustomImageView(
                                                imagePath: ImageConstant.img177,
                                                height: 74.v,
                                                width: 75.h,
                                                alignment:
                                                    Alignment.bottomRight,
                                                margin: EdgeInsets.only(
                                                    right: 20.h),
                                                onTap: () {
                                                  onTapImgImagefive(context);
                                                })
                                          ]))
                                ]))
                      ]))));
    });
  }

  /// Navigates to the iphone14ProMaxOneContainer1Screen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxOneContainer1Screen.
  onTapImgImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxOneContainer1Screen,
    );
  }

  /// Navigates to the iphone14ProMaxSixScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxSixScreen.
  onTapImgImageone(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxSixScreen,
    );
  }

  /// Navigates to the iphone14ProMaxSevenScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxSevenScreen.
  onTapImgImagetwo(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxSevenScreen,
    );
  }

  /// Navigates to the iphone14ProMaxEightScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxEightScreen.
  onTapImgImagethree(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxEightScreen,
    );
  }

  /// Navigates to the iphone14ProMaxOneContainer1Screen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxOneContainer1Screen.
  onTapImgImagefour(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxOneContainer1Screen,
    );
  }

  /// Navigates to the iphone14ProMaxSixScreen when the action is triggered.
  ///
  /// The [BuildContext] parameter is used to build the navigation stack.
  /// When the action is triggered, this function uses the [NavigatorService]
  /// to push the named route for the iphone14ProMaxSixScreen.
  onTapImgImagefive(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.iphone14ProMaxSixScreen,
    );
  }
}
