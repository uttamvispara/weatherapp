import 'bloc/iphone_14_pro_max_two_bloc.dart';
import 'models/iphone_14_pro_max_two_model.dart';
import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container_page/iphone_14_pro_max_one_container_page.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_three_page/iphone_14_pro_max_three_page.dart';
import 'package:uttam_s_application8/widgets/app_bar/appbar_subtitle_1.dart';
import 'package:uttam_s_application8/widgets/app_bar/appbar_title.dart';
import 'package:uttam_s_application8/widgets/app_bar/custom_app_bar.dart';
import 'package:uttam_s_application8/widgets/custom_bottom_bar.dart';

class Iphone14ProMaxTwoScreen extends StatelessWidget {
  Iphone14ProMaxTwoScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone14ProMaxTwoBloc>(
      create: (context) => Iphone14ProMaxTwoBloc(Iphone14ProMaxTwoState(
        iphone14ProMaxTwoModelObj: Iphone14ProMaxTwoModel(),
      ))
        ..add(Iphone14ProMaxTwoInitialEvent()),
      child: Iphone14ProMaxTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone14ProMaxTwoBloc, Iphone14ProMaxTwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            appBar: CustomAppBar(
              centerTitle: true,
              title: SizedBox(
                height: 121.v,
                width: 261.h,
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    AppbarTitle(
                      text: "lbl_rajkot".tr,
                      margin: EdgeInsets.only(
                        left: 33.h,
                        right: 32.h,
                        bottom: 25.v,
                      ),
                    ),
                    AppbarSubtitle1(
                      text: "msg_chances_of_rain".tr,
                      margin: EdgeInsets.only(top: 90.v),
                    ),
                  ],
                ),
              ),
            ),
            body: Container(
              width: mediaQueryData.size.width,
              height: mediaQueryData.size.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0, -0.22),
                  end: Alignment(1.29, 1.29),
                  colors: [
                    theme.colorScheme.secondaryContainer,
                    appTheme.indigo900,
                  ],
                ),
              ),
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 21.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      height: 164.v,
                      width: 322.h,
                      margin: EdgeInsets.only(right: 17.h),
                      child: Stack(
                        alignment: Alignment.topLeft,
                        children: [
                          Align(
                            alignment: Alignment.topRight,
                            child: Text(
                              "lbl_23".tr,
                              style: CustomTextStyles.poppinsIndigo300,
                            ),
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.img171113x114,
                            height: 113.v,
                            width: 114.h,
                            alignment: Alignment.topLeft,
                            margin: EdgeInsets.only(top: 15.v),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Padding(
                              padding: EdgeInsets.only(left: 93.h),
                              child: Text(
                                "lbl_forecast".tr,
                                style: CustomTextStyles
                                    .headlineSmallOnPrimaryContainer,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 26.v),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 23.h,
                        vertical: 40.v,
                      ),
                      decoration: AppDecoration.fillOnPrimaryContainer.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder43,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                              left: 17.h,
                              right: 27.h,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.img74,
                                  height: 60.v,
                                  width: 64.h,
                                  margin: EdgeInsets.only(top: 7.v),
                                ),
                                Spacer(),
                                Padding(
                                  padding: EdgeInsets.only(bottom: 7.v),
                                  child: Text(
                                    "lbl_28".tr,
                                    style: theme.textTheme.displayMedium,
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                    left: 23.h,
                                    top: 7.v,
                                    bottom: 11.v,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "lbl_monday".tr,
                                        style: CustomTextStyles
                                            .titleLargeOnPrimaryContainer,
                                      ),
                                      Text(
                                        "lbl_21_august".tr,
                                        style: theme.textTheme.bodyLarge,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 28.v),
                            child: Divider(
                              color: theme.colorScheme.onPrimaryContainer,
                              indent: 7.h,
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: EdgeInsets.only(
                                left: 17.h,
                                top: 22.v,
                                right: 27.h,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.img7460x64,
                                    height: 60.v,
                                    width: 64.h,
                                    margin: EdgeInsets.only(top: 7.v),
                                  ),
                                  Spacer(),
                                  Padding(
                                    padding: EdgeInsets.only(bottom: 7.v),
                                    child: Text(
                                      "lbl_22".tr,
                                      style: theme.textTheme.displayMedium,
                                    ),
                                  ),
                                  Container(
                                    height: 48.v,
                                    width: 85.h,
                                    margin: EdgeInsets.only(
                                      left: 21.h,
                                      top: 8.v,
                                      bottom: 11.v,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: Text(
                                            "lbl_tuesday".tr,
                                            style: CustomTextStyles
                                                .titleLargeOnPrimaryContainer,
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Text(
                                            "lbl_21_august".tr,
                                            style: theme.textTheme.bodyLarge,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 28.v),
                            child: Divider(
                              color: theme.colorScheme.onPrimaryContainer,
                              indent: 7.h,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.fromLTRB(17.h, 22.v, 3.h, 29.v),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.img741,
                                  height: 60.v,
                                  width: 64.h,
                                  margin: EdgeInsets.only(top: 7.v),
                                ),
                                Spacer(),
                                Padding(
                                  padding: EdgeInsets.only(bottom: 7.v),
                                  child: Text(
                                    "lbl_29".tr,
                                    style: theme.textTheme.displayMedium,
                                  ),
                                ),
                                Container(
                                  height: 48.v,
                                  width: 120.h,
                                  margin: EdgeInsets.only(
                                    left: 9.h,
                                    top: 7.v,
                                    bottom: 11.v,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.bottomLeft,
                                    children: [
                                      Align(
                                        alignment: Alignment.topCenter,
                                        child: Text(
                                          "lbl_wednesday".tr,
                                          style: CustomTextStyles
                                              .titleLargeOnPrimaryContainer,
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 15.h),
                                          child: Text(
                                            "lbl_21_august".tr,
                                            style: theme.textTheme.bodyLarge,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ),
            bottomNavigationBar: CustomBottomBar(
              onChanged: (BottomBarEnum type) {
                Navigator.pushNamed(
                    navigatorKey.currentContext!, getCurrentRoute(type));
              },
            ),
          ),
        );
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Search:
        return AppRoutes.iphone14ProMaxOneContainerPage;
      case BottomBarEnum.Ellipse1:
        return AppRoutes.iphone14ProMaxThreePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.iphone14ProMaxOneContainerPage:
        return Iphone14ProMaxOneContainerPage.builder(context);
      case AppRoutes.iphone14ProMaxThreePage:
        return Iphone14ProMaxThreePage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
