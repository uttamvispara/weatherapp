import 'package:flutter/material.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_four_screen/iphone_14_pro_max_four_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_five_screen/iphone_14_pro_max_five_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_one_container1_screen/iphone_14_pro_max_one_container1_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_two_screen/iphone_14_pro_max_two_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_six_screen/iphone_14_pro_max_six_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_seven_screen/iphone_14_pro_max_seven_screen.dart';
import 'package:uttam_s_application8/presentation/iphone_14_pro_max_eight_screen/iphone_14_pro_max_eight_screen.dart';
import 'package:uttam_s_application8/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String iphone14ProMaxFourScreen =
      '/iphone_14_pro_max_four_screen';

  static const String iphone14ProMaxFiveScreen =
      '/iphone_14_pro_max_five_screen';

  static const String iphone14ProMaxOneContainerPage =
      '/iphone_14_pro_max_one_container_page';

  static const String iphone14ProMaxOneContainer1Screen =
      '/iphone_14_pro_max_one_container1_screen';

  static const String iphone14ProMaxTwoScreen = '/iphone_14_pro_max_two_screen';

  static const String iphone14ProMaxThreePage = '/iphone_14_pro_max_three_page';

  static const String iphone14ProMaxSixScreen = '/iphone_14_pro_max_six_screen';

  static const String iphone14ProMaxSevenScreen =
      '/iphone_14_pro_max_seven_screen';

  static const String iphone14ProMaxEightScreen =
      '/iphone_14_pro_max_eight_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        iphone14ProMaxFourScreen: Iphone14ProMaxFourScreen.builder,
        iphone14ProMaxFiveScreen: Iphone14ProMaxFiveScreen.builder,
        iphone14ProMaxOneContainer1Screen:
            Iphone14ProMaxOneContainer1Screen.builder,
        iphone14ProMaxTwoScreen: Iphone14ProMaxTwoScreen.builder,
        iphone14ProMaxSixScreen: Iphone14ProMaxSixScreen.builder,
        iphone14ProMaxSevenScreen: Iphone14ProMaxSevenScreen.builder,
        iphone14ProMaxEightScreen: Iphone14ProMaxEightScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: Iphone14ProMaxFourScreen.builder
      };
}
