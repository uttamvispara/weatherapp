import 'package:flutter/material.dart';
import 'package:uttam_s_application8/core/app_export.dart';

class AppDecoration {
  // Fill decorations
  static BoxDecoration get fillOnInverseSurface => BoxDecoration(
        color: theme.colorScheme.onInverseSurface,
      );
  static BoxDecoration get fillOnPrimaryContainer => BoxDecoration(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(0.29),
      );
  static BoxDecoration get fillOnPrimaryContainer1 => BoxDecoration(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
      );

  // Gradient decorations
  static BoxDecoration get gradientIndigoToIndigo => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0.5, 0),
          end: Alignment(1.17, 1.18),
          colors: [
            appTheme.indigo300.withOpacity(0.29),
            appTheme.indigo900.withOpacity(0.42),
          ],
        ),
      );
  static BoxDecoration get gradientSecondaryContainerToIndigo => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -0.22),
          end: Alignment(1.29, 1.29),
          colors: [
            theme.colorScheme.secondaryContainer,
            appTheme.indigo900,
          ],
        ),
      );
  static BoxDecoration get gradientSurfaceVariantToIndigo => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -0.22),
          end: Alignment(1.29, 1.29),
          colors: [
            theme.colorScheme.surfaceVariant,
            appTheme.indigo900,
          ],
        ),
      );

  // Outline decorations
  static BoxDecoration get outlineBlack => BoxDecoration();
}

class BorderRadiusStyle {
  // Circle borders
  static BorderRadius get circleBorder20 => BorderRadius.circular(
        20.h,
      );
  static BorderRadius get circleBorder50 => BorderRadius.circular(
        50.h,
      );

  // Rounded borders
  static BorderRadius get roundedBorder27 => BorderRadius.circular(
        27.h,
      );
  static BorderRadius get roundedBorder43 => BorderRadius.circular(
        43.h,
      );
}

// Comment/Uncomment the below code based on your Flutter SDK version.

// For Flutter SDK Version 3.7.2 or greater.

double get strokeAlignInside => BorderSide.strokeAlignInside;

double get strokeAlignCenter => BorderSide.strokeAlignCenter;

double get strokeAlignOutside => BorderSide.strokeAlignOutside;

// For Flutter SDK Version 3.7.1 or less.

// StrokeAlign get strokeAlignInside => StrokeAlign.inside;
//
// StrokeAlign get strokeAlignCenter => StrokeAlign.center;
//
// StrokeAlign get strokeAlignOutside => StrokeAlign.outside;
