import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Display text style
  static get displayLarge64 => theme.textTheme.displayLarge!.copyWith(
        fontSize: 64.fSize,
      );
  static get displayLargeBlue5001 => theme.textTheme.displayLarge!.copyWith(
        color: appTheme.blue5001,
        fontSize: 64.fSize,
      );
  static get displayMediumBlack900 => theme.textTheme.displayMedium!.copyWith(
        color: appTheme.black900,
        fontSize: 48.fSize,
      );
  static get displayMediumTeal50 => theme.textTheme.displayMedium!.copyWith(
        color: appTheme.teal50,
      );
  // Headline text style
  static get headlineSmallBlack900 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.black900,
      );
  static get headlineSmallBlack900_1 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.black900.withOpacity(0.5),
      );
  static get headlineSmallOnPrimaryContainer =>
      theme.textTheme.headlineSmall!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
      );
  static get headlineSmallPrimary => theme.textTheme.headlineSmall!.copyWith(
        color: theme.colorScheme.primary,
      );
  static get headlineSmallPrimaryContainer =>
      theme.textTheme.headlineSmall!.copyWith(
        color: theme.colorScheme.primaryContainer,
      );
  static get headlineSmallTeal50 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.teal50,
      );
  // Poppins text style
  static get poppinsBlue5001 => TextStyle(
        color: appTheme.blue5001,
        fontSize: 200.fSize,
        fontWeight: FontWeight.w400,
      ).poppins;
  static get poppinsIndigo300 => TextStyle(
        color: appTheme.indigo300,
        fontSize: 100.fSize,
        fontWeight: FontWeight.w400,
      ).poppins;
  // Title text style
  static get titleLargeBluegray400 => theme.textTheme.titleLarge!.copyWith(
        color: appTheme.blueGray400,
      );
  static get titleLargeOnPrimaryContainer =>
      theme.textTheme.titleLarge!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
      );
}

extension on TextStyle {
  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }
}
